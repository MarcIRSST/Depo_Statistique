
jQuery(document).ready(function () {
    // setup collapse
    jQuery(".fsj_faqs_cat_accordion").collapse();
    jQuery('.fsj_faqs_faq_accordion').collapse();

    // if page is accessed using a # then expand any sections to expose that and ensure its visible
    try {
        var hash = window.location.hash;
        hash = hash.replace("#faq_", "");
        var el = jQuery('div[faq_id="' + hash + '"]');
        fsj_faqs_show_accordion(el);

        // better version of scrolling into view needed here!
        jQuery('html,body').animate({ scrollTop: jQuery('a[name="faq_' + hash + '"]').offset().top });
    } catch (e) {
    }

    // when expanding an faq, set the # so it can easliy be linked to
    /*jQuery('.collapse').on('show', function () {
        var faq = jQuery(this).attr('faq_id');
        if (faq) {
            var hash = '#faq_' + faq;

            if (history.pushState) {
                history.pushState(null, null, hash);
            }
        }
    })*/
});

function fsj_faqs_show_accordion(el) {
    if (el.hasClass('collapse'))
        el.collapse("show");

    if (el.parent().length > 0)
        fsj_faqs_show_accordion(el.parent());
}
